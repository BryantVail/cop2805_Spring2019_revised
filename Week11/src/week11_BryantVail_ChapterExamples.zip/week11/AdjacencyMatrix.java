package week11;

public class AdjacencyMatrix {
	
	public static void main(String[] args) {
		int[] [] adjacencyMatrix = {
				{0,1,0,1,0,1,0,0,0,0,0,0},//Seattle
				{1,0,1,1,0,0,0,0,0,0,0,0},//San Fran
				{0,1,0,1,1,1,0,0,0,0,0,0},//Los Angeles
				{1,1,1,0,1,1,0,0,0,0,0,0},//Denver
				{0,0,1,1,0,1,0,1,1,0,1,0},//Kansas City
				{1,0,0,1,1,0,1,1,0,0,0,0},//Chicago
				{0,0,0,0,0,1,0,1,0,0,0,0},//Boston
				{0,0,0,0,1,1,1,0,1,0,0,0},//New York
				{0,0,0,1,1,0,0,1,0,1,1,1},//Atlanta
				{0,0,0,0,0,0,0,0,1,0,0,1},//Miami
				{0,0,1,0,1,0,0,0,1,0,0,1},//Dallas
				{0,0,0,0,0,0,0,0,1,1,1,0} //Houston
		};
		
		
		//representation of 28.3a (according to the book), 
		int [] [] a = {
				{0,0,1,0,0},//Peter
				{0,0,1,0,0},//Jane
				{0,0,0,0,1},//Mark
				{0,0,0,0,1},//Cindy
				{0,0,0,0,0} //Wendy
		};
		
	}

}
























































