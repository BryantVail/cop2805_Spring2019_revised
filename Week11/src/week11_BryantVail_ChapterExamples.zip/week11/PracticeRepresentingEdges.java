package week11;

public class PracticeRepresentingEdges {

	public static void main(String[] args) {
		// 
		//edge Array
		int[][] edges = {
				{0,1}, {0,3}, {0, 5},
				{1,0}, {1,2}, {1,3}, 
				{2,1}, {2,3}, {2,4}, {2,10}, 
				{3,0}, {3,1}, {3,2}, {3,4}, {3,5},
				{4,2}, {4,3}, {4,5}, {4,7}, {4,8}, {4,10}, 
				{5,0}, {5,3}, {5,4}, {5,6}, {5,7},
				{6,5}, {6, 7}, 
		};

	}

}
